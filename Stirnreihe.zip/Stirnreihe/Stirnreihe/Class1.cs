namespace Stirnreihe
{
  public class Person
  {
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public int Height { get; set; }

    public override string ToString()
    {
      return $"{LastName}, {FirstName} ({Height})";
    }

  }

  public class Node
  {
    public Person? Person { get; set; }
    public Node? Next { get; set; }
  }

  public class LineOfPeople
  {
    public Node? First = null;

    public void AddToFront(Person Person)
    {
      var temp = First;
      First = new Node();
      First.Person = Person;
      First.Next = temp;
    }
    public void Clear()
    {
      while (First != null)
      {
        var temp = First;
        First = First.Next;
        temp.Next = null;
      }
    }
    public void AddSorted(Person person)
    {


    }
  }
}
