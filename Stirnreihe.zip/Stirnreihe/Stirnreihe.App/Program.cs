using Stirnreihe;
Console.WriteLine($"Welcome to the Stirnreihe World Record App! What do you want to do?\n" +
    $"1) Add a person to the line\n" +
    $"2) Print the line\n" +
    $"3) Clear the line\n" +
    $"4) Exit");
Console.Write($"Your choice: ");
var selection = Console.ReadLine();
LineOfPeople lineOfPeople = new LineOfPeople();
while (selection != "4")
{

  switch (selection)
  {
    case "1":
      var p = new Person();
      Console.Write($"First Name: ");
      string firstName = Console.ReadLine()!;
      Console.Write($"Last Name: ");
      string lastName = Console.ReadLine()!;
      Console.Write($"Height in cm: ");
      int height = int.Parse(Console.ReadLine()!);
      p.FirstName = firstName;
      p.LastName = lastName;
      p.Height = height;
      lineOfPeople.AddToFront(p);
      break;
    case "2":
      var current = lineOfPeople.First;
      while (current != null)
      {
        Console.WriteLine(current.Person);
        current = current.Next;
      }
      break;
    case "3":
      lineOfPeople.Clear();
      break;
  }
  Console.Write($"Your Choice: ");
  selection = Console.ReadLine();
}
